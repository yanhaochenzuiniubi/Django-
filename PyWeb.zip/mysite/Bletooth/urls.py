from django.urls import path
from . import views
from django.views.static import serve
from django.conf.urls import url 

urlpatterns = [
    path('',views.home,name="home"),
    path('upload/',views.index,name="index"),
    path('to_upload',views.upload)
]