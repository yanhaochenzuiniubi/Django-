from django.shortcuts import redirect, render
from django.db import connection

# Create your views here.
def home(request):
    mycursor = connection.cursor()
    f = open(r'/root/mac/log.txt')
    beacon_mac = f.read()
    sql = "select * from db_beacon where beacon_mac = %s "
    mycursor.execute(sql,beacon_mac)
    rows = mycursor.fetchall()
    
    data ={
        "beacon":rows 
    }
    return render(request,'home.html',context=data)

#文件上传测试
def index(request):
    return render(request,'file.html')

#接受文件
def upload(request):
    rec_file = request.FILES.get('upload_file')
    with open(f'/root/mac/{rec_file.name}','wb') as f:
        f.write(rec_file.read())
    return redirect('/upload/')


