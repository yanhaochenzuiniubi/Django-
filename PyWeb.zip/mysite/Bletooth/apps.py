from django.apps import AppConfig


class BletoothConfig(AppConfig):
    name = 'Bletooth'
    