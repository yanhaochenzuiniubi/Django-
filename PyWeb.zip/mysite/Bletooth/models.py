from django.db import models

class BlueToothManager(models.Model):
    beacon_uuid = models.CharField(max_length=100)
    beacon_mac = models.CharField(max_length=100,primary_key=True)
    beacon_name = models.CharField(max_length=50)
    beacon_major = models.CharField(max_length=50)
    beacon_minor = models.CharField(max_length=50)
    imgs = models.CharField(max_length=50)
    
    class Meta:
        db_table = 'db_beacon'
        verbose_name = "展厅展台的数据库内容"
        verbose_name_plural = "数据库管理"