from django.contrib import admin
from Bletooth.models import BlueToothManager

# Register your models here.
admin.site.site_title="掌上微展厅"
admin.site.site_header="掌上微展厅管理后台"
admin.site.index_title = '掌上微展厅'

admin.site.register(BlueToothManager)